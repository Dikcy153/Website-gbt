<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bepandir</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-sm navbar-dark" style="background:black";>
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#"><img src="https://i.imgocean.com/202303090002258997dd1960fe65fd37f.webp" alt="202303090002258997dd1960fe65fd37f.webp" width="100px" alt=""></a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php?page=Home">HOME</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="index.php?page=masa lalu kelam">Masa lalu kelam</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="index.php?page=orang gila">orang gila</a>
    </li>
  </ul>
</nav>

<?php

include 'library.php';
 
?>



</body>
</html>